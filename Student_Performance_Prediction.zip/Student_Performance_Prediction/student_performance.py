import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import joblib

from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.inspection import permutation_importance

# -----------------------------------
# 1. PROJECT PATHS
# -----------------------------------

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(BASE_DIR, "outputs")

os.makedirs(OUTPUT_DIR, exist_ok=True)

DATA_PATH = os.path.join(BASE_DIR, "student-mat.csv")
MODEL_PATH = os.path.join(BASE_DIR, "student_model.pkl")

# -----------------------------------
# 2. CREATE DATASET IF EMPTY
# -----------------------------------

if not os.path.exists(DATA_PATH) or os.path.getsize(DATA_PATH) == 0:

    print("Creating a sample student dataset...")

    np.random.seed(42)
    n = 500

    data = pd.DataFrame({
        "studytime": np.random.randint(1, 5, n),
        "absences": np.random.randint(0, 25, n),
        "failures": np.random.randint(0, 4, n),
        "G1": np.random.randint(5, 20, n),
        "G2": np.random.randint(5, 20, n),
        "attendance": np.random.randint(60, 101, n),
        "assignments": np.random.randint(40, 101, n),
        "participation": np.random.randint(1, 11, n)
    })

    noise = np.random.normal(0, 1.5, n)

    data["G3"] = (
        0.30 * data["G1"]
        + 0.35 * data["G2"]
        + 0.08 * data["studytime"]
        + 0.025 * data["attendance"]
        + 0.025 * data["assignments"]
        + 0.12 * data["participation"]
        - 0.15 * data["absences"]
        - 1.2 * data["failures"]
        + noise
    ).clip(0, 20).round(1)

    data.to_csv(DATA_PATH, index=False)

    print("Sample dataset created successfully!")

# -----------------------------------
# 3. LOAD DATASET
# -----------------------------------

data = pd.read_csv(DATA_PATH)

print("\nSTUDENT PERFORMANCE PREDICTION")
print("=" * 45)

print("\nFirst five records:")
print(data.head())

print("\nDataset shape:")
print(data.shape)

print("\nMissing values:")
print(data.isnull().sum())

print("\nDuplicate records:")
print(data.duplicated().sum())

# -----------------------------------
# 4. DATA CLEANING
# -----------------------------------

data = data.drop_duplicates()

data = data.dropna()

print("\nCleaned dataset shape:")
print(data.shape)

# -----------------------------------
# 5. EXPLORATORY DATA ANALYSIS
# -----------------------------------

sns.set_theme(style="whitegrid")

plt.figure(figsize=(8, 5))
sns.histplot(data["G3"], bins=15, kde=True)
plt.title("Student Performance Distribution")
plt.xlabel("Final Grade")
plt.ylabel("Number of Students")
plt.tight_layout()
plt.savefig(os.path.join(
    OUTPUT_DIR, "performance_distribution.png"
))
plt.close()

plt.figure(figsize=(10, 7))
sns.heatmap(
    data.corr(numeric_only=True),
    annot=True,
    cmap="coolwarm",
    fmt=".2f"
)
plt.title("Student Performance Correlation")
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "correlation.png"))
plt.close()

print("\nEDA graphs generated successfully!")

# -----------------------------------
# 6. FEATURE SELECTION
# -----------------------------------

X = data.drop(columns=["G3"])
y = data["G3"]

categorical_features = X.select_dtypes(
    include=["object", "category"]
).columns.tolist()

numerical_features = X.select_dtypes(
    include=["number"]
).columns.tolist()

preprocessor = ColumnTransformer([
    (
        "categorical",
        OneHotEncoder(handle_unknown="ignore"),
        categorical_features
    ),
    ("numerical", "passthrough", numerical_features)
])

# -----------------------------------
# 7. TRAIN-TEST SPLIT
# -----------------------------------

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42
)

print("\nTraining records:", len(X_train))
print("Testing records:", len(X_test))

# -----------------------------------
# 8. TRAIN MACHINE LEARNING MODELS
# -----------------------------------

models = {
    "Linear Regression": LinearRegression(),
    "Random Forest": RandomForestRegressor(
        n_estimators=150,
        random_state=42
    )
}

results = {}

for name, algorithm in models.items():

    pipeline = Pipeline([
        ("preprocessor", preprocessor),
        ("model", algorithm)
    ])

    pipeline.fit(X_train, y_train)

    predictions = pipeline.predict(X_test)

    mae = mean_absolute_error(y_test, predictions)
    mse = mean_squared_error(y_test, predictions)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_test, predictions)

    results[name] = {
        "MAE": mae,
        "MSE": mse,
        "RMSE": rmse,
        "R2": r2
    }

    print("\n", name)
    print("MAE:", round(mae, 3))
    print("MSE:", round(mse, 3))
    print("RMSE:", round(rmse, 3))
    print("R2 Score:", round(r2, 3))

    if name == "Random Forest":
        best_model = pipeline

# -----------------------------------
# 9. SAVE MODEL
# -----------------------------------

joblib.dump(best_model, MODEL_PATH)

print("\nBest model saved successfully!")

# -----------------------------------
# 10. FEATURE IMPORTANCE
# -----------------------------------

importance = permutation_importance(
    best_model,
    X_test,
    y_test,
    n_repeats=5,
    random_state=42,
    scoring="r2"
)

importance_df = pd.DataFrame({
    "Feature": X.columns,
    "Importance": importance.importances_mean
}).sort_values(by="Importance", ascending=False)

plt.figure(figsize=(9, 6))

sns.barplot(
    data=importance_df,
    x="Importance",
    y="Feature"
)

plt.title("Feature Importance")
plt.tight_layout()

plt.savefig(
    os.path.join(OUTPUT_DIR, "feature_importance.png")
)

plt.close()

# -----------------------------------
# 11. SAVE MODEL RESULTS
# -----------------------------------

results_df = pd.DataFrame(results).T

results_df.to_csv(
    os.path.join(OUTPUT_DIR, "model_results.csv")
)

importance_df.to_csv(
    os.path.join(OUTPUT_DIR, "feature_importance.csv"),
    index=False
)

print("\nAll graphs and results saved in outputs folder!")

print("\nPROJECT COMPLETED SUCCESSFULLY!")