import streamlit as st
import pandas as pd
import numpy as np
import joblib
import os
import matplotlib.pyplot as plt
import seaborn as sns

# -------------------------------------------------
# PAGE CONFIGURATION
# -------------------------------------------------

st.set_page_config(
    page_title="Student Performance Prediction",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded"
)

# -------------------------------------------------
# DARK THEME CSS
# -------------------------------------------------

st.markdown("""
<style>
.stApp {
    background: linear-gradient(135deg, #0b1120, #111c32);
    color: #f1f5f9;
}

[data-testid="stSidebar"] {
    background-color: #111827;
}

.main-title {
    font-size: 38px;
    font-weight: 800;
    color: #ffffff;
    text-align: center;
}

.subtitle {
    text-align: center;
    color: #94a3b8;
    font-size: 16px;
    margin-bottom: 30px;
}

.section-title {
    color: #93c5fd;
    font-size: 22px;
    font-weight: 700;
    margin-top: 15px;
}

div[data-testid="stMetric"] {
    background: #1e293b;
    border: 1px solid #334155;
    padding: 18px;
    border-radius: 14px;
}

div.stButton > button {
    background: linear-gradient(90deg, #2563eb, #7c3aed);
    color: white;
    border: none;
    border-radius: 10px;
    padding: 12px 20px;
    font-weight: bold;
    width: 100%;
}

div.stButton > button:hover {
    background: linear-gradient(90deg, #1d4ed8, #6d28d9);
    color: white;
    border: none;
}

div[data-testid="stForm"] {
    background-color: #162238;
    padding: 20px;
    border-radius: 15px;
    border: 1px solid #334155;
}

</style>
""", unsafe_allow_html=True)

# -------------------------------------------------
# LOAD MODEL
# -------------------------------------------------

MODEL_FILE = "student_model.pkl"

@st.cache_resource
def load_model():
    return joblib.load(MODEL_FILE)

# -------------------------------------------------
# HEADER
# -------------------------------------------------

st.markdown(
    '<div class="main-title">🎓 Student Performance Prediction</div>',
    unsafe_allow_html=True
)

st.markdown(
    '<div class="subtitle">AI-Powered Academic Analytics Dashboard</div>',
    unsafe_allow_html=True
)

# -------------------------------------------------
# SIDEBAR
# -------------------------------------------------

with st.sidebar:
    st.markdown("## 🎓 Student Analytics")
    st.markdown("---")

    st.markdown("### About Project")
    st.write(
        "This application uses machine learning "
        "to estimate student final academic grades "
        "from academic and behavioural information."
    )

    st.markdown("---")
    st.markdown("### Technologies")
    st.write("🐍 Python")
    st.write("📊 Pandas & NumPy")
    st.write("🤖 Scikit-learn")
    st.write("📈 Matplotlib & Seaborn")
    st.write("🌐 Streamlit")

    st.markdown("---")
    st.caption("Student Performance Prediction | GR-2")

# -------------------------------------------------
# MODEL CHECK
# -------------------------------------------------

if not os.path.exists(MODEL_FILE):
    st.error(
        "Trained model not found. Please run "
        "student_performance.py first."
    )
    st.stop()

try:
    model = load_model()
except Exception as e:
    st.error(f"Could not load model: {e}")
    st.stop()

# -------------------------------------------------
# INPUT FORM
# -------------------------------------------------

st.markdown(
    '<div class="section-title">📋 Student Information</div>',
    unsafe_allow_html=True
)

st.write(
    "Enter the student's academic and behavioural details "
    "to estimate the expected final grade."
)

with st.form("student_prediction_form"):

    st.markdown("### 📚 Academic Details")

    col1, col2 = st.columns(2)

    with col1:
        studytime = st.slider(
            "Study Time (1–4)",
            min_value=1,
            max_value=4,
            value=3
        )

        failures = st.number_input(
            "Previous Failures",
            min_value=0,
            max_value=3,
            value=0,
            step=1
        )

        G1 = st.slider(
            "First Period Grade (G1)",
            min_value=0,
            max_value=20,
            value=15
        )

        G2 = st.slider(
            "Second Period Grade (G2)",
            min_value=0,
            max_value=20,
            value=16
        )

    with col2:
        absences = st.number_input(
            "Number of Absences",
            min_value=0,
            max_value=100,
            value=5,
            step=1
        )

        attendance = st.slider(
            "Attendance Percentage",
            min_value=0,
            max_value=100,
            value=90
        )

        assignments = st.slider(
            "Assignment Performance",
            min_value=0,
            max_value=100,
            value=85
        )

        participation = st.slider(
            "Class Participation (1–10)",
            min_value=1,
            max_value=10,
            value=8
        )

    submitted = st.form_submit_button(
        "🚀 Predict Student Performance"
    )

# -------------------------------------------------
# PREDICTION
# -------------------------------------------------

if submitted:

    input_data = pd.DataFrame([{
        "studytime": studytime,
        "absences": absences,
        "failures": failures,
        "G1": G1,
        "G2": G2,
        "attendance": attendance,
        "assignments": assignments,
        "participation": participation
    }])

    try:
        prediction = float(model.predict(input_data)[0])
        prediction = float(np.clip(prediction, 0, 20))

        st.markdown("---")
        st.markdown(
            '<div class="section-title">📊 Prediction Results</div>',
            unsafe_allow_html=True
        )

        col1, col2 = st.columns(2)

        with col1:
            st.metric(
                "Predicted Final Grade",
                f"{prediction:.2f} / 20"
            )

        with col2:
            if prediction >= 16:
                category = "Excellent"
            elif prediction >= 12:
                category = "Good"
            elif prediction >= 10:
                category = "Satisfactory"
            else:
                category = "Needs Improvement"

            st.metric(
                "Estimated Performance",
                category
            )

        st.progress(int(round(prediction / 20 * 100)))

        st.info(
            "This is a machine-learning estimate, "
            "not a guaranteed examination result."
        )

        # Input summary
        st.markdown("### Student Input Summary")
        st.dataframe(input_data, use_container_width=True)

    except Exception as e:
        st.error(f"Prediction failed: {e}")

# -------------------------------------------------
# OUTPUT CHARTS
# -------------------------------------------------

st.markdown("---")
st.markdown(
    '<div class="section-title">📈 Project Analytics</div>',
    unsafe_allow_html=True
)

chart_files = [
    ("Student Performance Distribution",
     "outputs/performance_distribution.png"),
    ("Correlation Heatmap",
     "outputs/correlation.png"),
    ("Feature Importance",
     "outputs/feature_importance.png")
]

chart_columns = st.columns(3)

for i, (title, file_path) in enumerate(chart_files):
    with chart_columns[i]:
        st.markdown(f"**{title}**")

        if os.path.exists(file_path):
            st.image(file_path, use_container_width=True)
        else:
            st.warning("Chart not found. Run the training script.")

# -------------------------------------------------
# MODEL RESULTS
# -------------------------------------------------

st.markdown("---")
st.markdown(
    '<div class="section-title">🤖 Model Evaluation</div>',
    unsafe_allow_html=True
)

results_file = "outputs/model_results.csv"

if os.path.exists(results_file):
    results = pd.read_csv(results_file)
    st.dataframe(results, use_container_width=True)
else:
    st.info("Model results will appear after model training.")

# -------------------------------------------------
# FOOTER
# -------------------------------------------------

st.markdown("---")

st.markdown(
    """
    <div style="text-align:center; color:#94a3b8;">
        <p>🎓 Student Performance Prediction System</p>
        <p>Developed using Python, Machine Learning and Streamlit</p>
        <p>GR-2 Academic Project</p>
    </div>
    """,
    unsafe_allow_html=True
)