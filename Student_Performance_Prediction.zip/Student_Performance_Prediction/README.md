# Student Performance Prediction

## Project Description
This project uses Machine Learning to predict student academic performance based on academic and behavioural factors.

## Technologies Used
- Python
- Pandas
- NumPy
- Matplotlib
- Seaborn
- Scikit-learn
- Streamlit

## Features
- Dataset creation and preprocessing
- Exploratory Data Analysis
- Correlation analysis
- Feature importance analysis
- Linear Regression
- Random Forest Regression
- Model evaluation
- Student performance prediction interface

## Evaluation Metrics
- Mean Absolute Error (MAE)
- Mean Squared Error (MSE)
- Root Mean Squared Error (RMSE)
- R2 Score

## How to Run

Install libraries:

pip install -r requirements.txt

Train the model:

python student_performance.py

Launch the application:

streamlit run app.py

## Expected Output
The system predicts student final grades and generates graphs showing student performance and important features.

## Dataset
A simulated dataset is generated automatically if the CSV file is missing or empty.